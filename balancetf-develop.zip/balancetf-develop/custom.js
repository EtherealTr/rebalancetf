const mainDiv = document.getElementsByTagName("main")[0];
mainDiv.innerHTML += "<hr><div class='discussion-footer'>Want to be a part of the discussion? Check out <a href='https://discord.gg/7GmCDUP'>the discord server</a>.</div>";
