# Contact Info

## Discord

We have a server where we handle discussion on item proposals with the community and certain keynote members of the community.

If you want to be apart of the discussion, then [check it out](https://discord.gg/7GmCDUP).

## Maintainers

### rrredface

* steam: [steamcommunity.com/id/bananabrrred](https://steamcommunity.com/id/bananabrrred/)
