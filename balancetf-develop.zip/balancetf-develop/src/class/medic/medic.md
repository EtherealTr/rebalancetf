# Medic

| Base Stats |       |
|------------|------:|
| Move Speed |  107% |
| Health     |  150  |

## Syringe Guns
* [Syringe Gun](items/syringe-gun.md)
* [Blutsauger](items/blutsauger.md)
* [Overdose](items/overdose.md)

## Crossbows
* [Crusader's Crossbow](items/crusaders.crossbow.md)

## Medi Guns
* [Medi Gun](items/medi-gun.md)
* [Kritzkrieg](items/kritzkrieg.md)
* [Quick-Fix](items/quick-fix.md)
* [Vaccinator](items/vaccinator.md)

## Bonesaws
* [Bonesaw](items/bonesaw.md)
* [Ubersaw](items/ubersaw.md)
* [Vita-saw](items/vita-saw.md)
* [Amputator](items/amputator.md)
* [Solemn Vow](items/solemn-vow.md)
