# Scout

| Base Stats |      |
|------------|-----:|
| Move Speed | 133% |
| Health     |  125 |

## Scatterguns
* [Scattergun](items/scattergun.md)
* [Force-A-Nature](items/force-a-nature.md)
* [Shortstop](items/shortstop.md)
* [Soda Popper](items/soda-popper.md)
* [Baby Face's Blaster](items/baby-faces-blaster.md)
* [Back Scatter](items/back-scatter.md)

## Pistols
* [Pistol](../multiclass/items/pistol.md)
* [Winger](items/winger.md)
* [Pretty Boy's Pocket Pistol](items/pretty-boys-pocket-pistol.md)

## Drinks
* [Bonk! Atomic Punch](items/bonk-atomic-punch.md)
* [Crit-a-Cola](items/crit-a-cola.md)

## Throwables
* [Flying Guillotine](items/flying-guillotine.md)
* [Mad Milk](items/mad-milk.md)

## Bats
* [Bat](items/bat.md)
* [Sandman](items/sandman.md)
* [Candy Cane](items/candy-cane.md)
* [Boston Basher](items/boston-basher.md)
* [Sun-on-a-Stick](items/sun-on-a-stick.md)
* [Fan o' War](items/fan-o-war.md)
* [Atomizer](items/atomizer.md)
* [Wrap Assasin](items/wrap-assassin.md)
