# Heavy

| Base Stats |      |
|------------|-----:|
| Move Speed |  77% |
| Health     |  300 |

## Miniguns
* [Minigun](items/minigun.md)
* [Natascha](items/natascha.md)
* [Brass Beast](items/brass-beast.md)
* [Tomislav](items/tomislav.md)
* [Huo-Long Heater](items/huo-long-heater.md)

## Shotguns
* [Shotgun](../multiclass/items/shotgun.md)
* [Family Business](items/family-business.md)
* [Panic Attack](../multiclass/items/panic-attack.md)

## Lunchboxes
* [Sandvich](items/sandvich.md)
* [Dalokohs Bar](items/dalokohs-bar.md)
* [Buffalo Steak Sandvich](items/buffalo-steak-sandvich.md)
* [Second Banana](items/second-banana.md)

## Fists
* [Fists](items/fists.md)
* [Killing Gloves of Boxing](items/killing-gloves-of-boxing.md)
* [Gloves of Running Urgently](items/gloves-of-running-urgently.md)
* [Warrior's Spirit](items/warriors-spirit.md)
* [Fists of Steel](items/fists-of-steel.md)
* [Eviction Notice](items/eviction-notice.md)
* [Holiday Punch](items/holiday-punch.md)
