# Multiclass

* [B.A.S.E Jumper](items/base-jumper.md)
* [Half Zatoichi](items/half-zatoichi.md)
* [Pain Train](items/pain-train.md)
* [Panic Attack](items/panic-attack.md)
* [Pistol](items/pistol.md)
* [Reserve Shooter](items/reserve-shooter.md)
* [Shotgun](items/shotgun.md)
