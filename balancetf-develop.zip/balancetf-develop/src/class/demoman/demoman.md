# Demoman

| Base Stats |      |
|------------|-----:|
| Move Speed |  93% |
| Health     |  175 |

## Grenade Launchers
* [Grenade Launcher](items/grenade-launcher.md)
* [Loch-n-Load](items/loch-n-load.md)
* [Loose Cannon](items/loose-cannon.md)
* [Iron Bomber](items/iron-bomber.md)

## Stickybomb Launchers
* [Stickybomb Launcher](items/stickybomb-launcher.md)
* [Scottish Resistance](items/scottish-resistance.md)
* [Sticky Jumper](items/sticky-jumper.md)
* [Quickiebomb Launcher](items/quickiebomb-launcher.md)

## Booties
* [Ali Baba's Wee Booties](items/ali-babas-wee-booties.md)

## Backpacks
* [B.A.S.E Jumper](../multiclass/items/base-jumper.md)

## Shields
* [Chargin Targe](items/chargin-targe.md)
* [Splendid Screen](items/splendid-screen.md)
* [Tide Turner](items/tide-turner.md)

## Bottles
* [Bottle](items/bottle.md)
* [Ullapool Caber](items/ullapool-caber.md)

## Swords
* [Eyelander](items/eyelander.md)
* [Scotsman's Skullcutter](items/scotsmans-skullcutter.md)
* [Claidheamh Mor](items/claidheamh-mor.md)
* [Pain Train](../multiclass/items/pain-train.md)
* [Half-Zatoichi](../multiclass/items/half-zatoichi.md)
* [Persian Persuader](items/persian-persuader.md)
