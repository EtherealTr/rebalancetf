# Sniper

| Base Stats |      |
|------------|-----:|
| Move Speed | 100% |
| Health     |  125 |

## Sniper Rifles
* [Sniper Rifle](items/sniper-rifle.md)
* [Sydney Sleeper](items/sydney-sleeper.md)
* [Bazaar Bargain](items/bazaar-bargain.md)
* [Machina](items/machina.md)
* [Hitman's Heatmaker](items/hitmans-heatmaker.md)
* [Classic](items/classic.md)

## Bows
* [Huntsman](items/huntsman.md)

## SMGs
* [SMG](items/smg.md)
* [Cleaner's Carbine](items/cleaners-carbine.md)

## Throwables
* [Jarate](items/jarate.md)

## Backpacks
* [Razorback](items/razorback.md)
* [Darwin's Danger Shield](items/darwins-danger-shield.md)
* [Cozy Camper](items/cozy-camper.md)

## Kukris
* [Kukri](items/kukri.md)
* [Tribalman's Shiv](items/tribalmans-shiv.md)
* [Bushwacka](items/bushwacka.md)
* [Shahanshah](items/shahanshah.md)
