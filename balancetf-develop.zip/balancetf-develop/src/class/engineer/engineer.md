# Engineer

| Base Stats |       |
|------------|------:|
| Move Speed |  100% |
| Health     |  125  |

## Shotguns
* [Shotgun](../multiclass/items/shotgun.md)
* [Frontier Justice](items/frontier-justice.md)
* [Widowmaker](items/widowmaker.md)
* [Pomson 6000](items/pomson-6000.md)
* [Rescue Ranger](items/rescue-ranger.md)
* [Panic Attack](../multiclass/items/panic-attack.md)

## Pistols
* [Pistol](../multiclass/items/pistol.md)
* [Wrangler](items/wrangler.md)
* [Short Circuit](items/short-circuit.md)

## Wrenches
* [Wrench](items/wrench.md)
* [Gunslinger](items/gunslinger.md)
* [Southern Hospitality](items/southern-hospitality.md)
* [Jag](items/jag.md)
* [Eureaka Effect](items/eureka-effect.md)

## PDAs
* [PDA](items/pda.md)
