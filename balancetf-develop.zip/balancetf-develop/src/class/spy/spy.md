# Spy

| Base Stats |      |
|------------|-----:|
| Move Speed | 107% |
| Health     |  125 |

## Revolvers
* [Revolver](items/revolver.md)
* [Ambassador](items/ambassador.md)
* [L'Etranger](items/letranger.md)
* [Enforcer](items/enforcer.md)
* [Diamondback](items/diamondback.md)

## Knives
* [Knife](items/knife.md)
* [Your Eternal Reward](items/your-eternal-reward.md)
* [Conniver's Kunai](items/connivers-kunai.md)
* [Big Earner](items/big-earner.md)
* [Spy-cicle](items/spy-cicle.md)

## Kits
* [Disguise Kit](items/disguise-kit.md)

## Watches
* [Invis Watch](items/invis-watch.md)
* [Cloak and Dagger](items/cloak-and-dagger.md)
* [Dead Ringer](items/dead-ringer.md)

## Sappers
* [Sapper](items/sapper.md)
* [Red-Tape Recorder](items/red-tape-recorder.md)
